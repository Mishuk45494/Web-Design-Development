<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
mishuk
<?php
$num1=40;
$num2=280;

?>

<h1>Mishuk</h1>

<?php
echo 'this my first program in PHP';
?> 
<div class="test">
    <h2>This is my first div </h2>
    <?php
echo 'this my first program in PHP<br>';

$result=$num1+$num2;
echo '<br>'.$result;
?> 
</div>
<div class="side">
    <h2>IIST</h2>
</div>
</body>
</html>